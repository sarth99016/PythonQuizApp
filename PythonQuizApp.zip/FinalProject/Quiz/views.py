from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.forms import UserCreationForm
from django.shortcuts import render, redirect

from .models import Question, Quiz


def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('login')
    else:
        form = UserCreationForm()
    return render(request, 'register.html', {'form': form})


def user_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return render(request, 'home.html')
    return render(request, 'login.html')


def quiz_view(request):
    questions = Question.objects.order_by('?')[:5]

    # Save questions in session
    request.session['questions'] = [q.id for q in questions]

    context = {'questions': questions}
    return render(request, 'quiz.html', context)


def submit_quiz(request):
    if request.method == 'POST':

        # Get original questions from session
        original_questions = Question.objects.filter(id__in=request.session.get('questions', []))

        score = 0
        # Check answers against original questions
        for q in original_questions:
            print('\n',request.POST.get(str(q.id)),'--',q.answer)
            print()
            # Check if answer matches
            if request.POST.get(str(q.id)) == q.answer:
                score += 1

        # Save quiz result
        quiz = Quiz.objects.create(user=request.user, score=score)
        percent = score/len(original_questions) * 100
        context = {'score': score, 'percent': percent}
        return render(request, 'result.html', context)

    return redirect('quiz')


def scores(request):
    quizzes = Quiz.objects.filter(user=request.user)
    total = len(quizzes)
    if total == 0:
        context = {
            'quizzes': quizzes,
            'total': 0,
            'average': 0,
            'highest': 0,
            'lowest': 0
        }
    else:
        average = sum(q.score for q in quizzes) / total
        average = round(average, 2)
        highest = max(q.score for q in quizzes)
        lowest = min(q.score for q in quizzes)

        context = {
            'quizzes': quizzes,
            'total': total,
            'average': average,
            'highest': highest,
            'lowest': lowest
        }

    return render(request, 'scores.html', context)


def user_logout(request):
    logout(request)
    return render(request, 'logout.html')
