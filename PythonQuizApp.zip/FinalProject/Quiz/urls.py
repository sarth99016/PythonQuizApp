from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [

    path('admin/', admin.site.urls),

    path('', views.register, name='register'),

    path('login/', views.user_login, name='login'),

    path('quiz/', views.quiz_view, name='quiz_view'),

    path('scores/', views.scores, name='scores'),

    path('logout/', views.user_logout, name='logout'),

    path('submit/', views.submit_quiz, name='submit_quiz'),

]